# cakery_repo_user
# Welcome to our Cakery App project

*About The Application*
> Hi Cakery Lovers, When it comes to a special day to celebrate, we know you want to eat the best cakes in your town. We are here for you. With Cakery, you'll be able to see all available cake shops and their delicious cakes in one application. You can choose one of the displayed items or you can even build your own cake and place an order with just one button and voi-la!  We're here to make sure you get the best cake for your celebration from Cakery to enjoy your special day! To see any update about application please check About The Application Part occasionally.

*The Crew*
- Melisa Uzulu
- Selin Akyurt
- Recep Berkay Engin

# Time Line ⌛
- [x] Project Proposal
- [x] Project Specifications Report
- [x] Analysis Report
- [x] High-Level Design Report
- [x] Presentations and Demonstrations 🎉
- [ ] Implementation 📱


For further information [Click Wix Page](https://oursitetedu.wixsite.com/cakeryapp) 🎂
