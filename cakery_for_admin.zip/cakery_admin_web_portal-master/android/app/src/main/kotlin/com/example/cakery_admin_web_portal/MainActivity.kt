package com.example.cakery_admin_web_portal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
