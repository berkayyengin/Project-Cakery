package com.example.cakery_repo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
